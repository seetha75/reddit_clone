import redditLogo from "./redditLogo.svg";

export {
    redditLogo
}