import React from 'react'

const Hero = () => {
  return (
    <section className='h-14 outline-none border-none'>
        
    </section>
  )
}

export default Hero