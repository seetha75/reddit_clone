import Channels from "./Channels";
import Posts from "./Posts";
import Recent from "./Recent";
import Hero from "./Hero";
import Create from "./Create";
import Home from "./Home";

export {
    Channels,
    Posts,
    Recent,
    Hero,
    Create,
    Home,
};